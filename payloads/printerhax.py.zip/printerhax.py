import telnetlib
host = raw_input("enter printer IP: ")
port = 9100
print "                       --------------------"
text = raw_input("Enter readymsg string: ")
tn = telnetlib.Telnet()
text = chr(27) + "%-12345X@PJL RDYMSG DISPLAY=\"" + text + "\"\n"
text2 = "%-12345X" + chr(29)
tn.open(host,port)
tn.write(text)
tn.write(text2)
tn.close()